-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2021 at 11:00 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dental`
--

-- --------------------------------------------------------

--
-- Table structure for table `advice`
--

CREATE TABLE `advice` (
  `ad_id` int(11) NOT NULL,
  `advice` text NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advice`
--

INSERT INTO `advice` (`ad_id`, `advice`, `date_time`) VALUES
(1, 'Gorgol with water.', '2017-12-16 05:16:40'),
(2, 'RCT', '2017-12-27 13:08:12'),
(3, 'X-Ray', '2017-12-27 13:08:27'),
(4, 'Filling', '2017-12-27 13:08:40'),
(5, 'water', '2021-02-07 15:22:41');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `name`, `date`) VALUES
(1, 'Cefixime', '0000-00-00 00:00:00'),
(2, 'Cefuroxime', '0000-00-00 00:00:00'),
(3, 'Metraonidazole', '0000-00-00 00:00:00'),
(4, 'Amoxicillin+ Clavulamic Acid', '0000-00-00 00:00:00'),
(5, 'Cephradine', '0000-00-00 00:00:00'),
(6, 'Clonagepam', '0000-00-00 00:00:00'),
(7, 'Rebeprazole', '2017-12-13 15:46:30'),
(8, 'Pentoprazole', '2017-12-13 15:46:41'),
(9, 'Omeprazole', '2017-12-13 15:55:15'),
(10, 'Esomeprazole', '2017-12-13 15:47:23'),
(11, 'Ibuprofen', '2017-12-13 15:47:38'),
(12, 'Renitidine', '2017-12-13 15:47:55'),
(13, 'Paracetamol', '2017-12-13 15:49:06'),
(14, 'Paracetamol+Caffeine', '2017-12-13 15:49:39'),
(15, 'Ketorolac', '2017-12-13 15:50:23'),
(16, 'Calcium Orotate', '2017-12-13 15:50:50'),
(17, 'Esomepra30le+Naproxen', '2017-12-13 15:52:27'),
(18, 'Calcium+Vitamin-D3', '2017-12-13 15:53:00'),
(19, 'Calcium', '2017-12-13 15:57:23'),
(20, 'Calcium+Vit. D3+Minerals', '2017-12-13 15:58:08'),
(21, 'Vit B1+B6+B12', '2017-12-13 15:59:16'),
(22, 'Gabapentin', '2017-12-13 15:59:35'),
(23, 'Pregabalin', '2017-12-13 16:00:10'),
(24, 'Ketorolac', '2017-12-13 16:01:17'),
(25, 'Aceclofenac', '2017-12-13 16:01:32'),
(26, 'Flucloxacillin', '2017-12-13 16:01:47'),
(27, 'Cefuroxime', '2017-12-13 16:02:03'),
(28, 'Cefuroxime+Clavulanic Acid', '2017-12-13 16:02:29'),
(29, 'Ceftibuten Dihydrate INN', '2017-12-13 16:02:55'),
(30, 'Cefixime', '2017-12-13 16:07:15'),
(31, 'Cefixime Trihydrate USP', '2017-12-13 16:07:38'),
(32, 'Ceftriaxone', '2017-12-13 16:07:53'),
(33, 'Tranexamic Acid', '2017-12-13 16:08:29'),
(34, 'Cefadroxil', '2017-12-27 13:12:57'),
(35, 'Clindamycin', '2017-12-27 13:31:27'),
(36, 'Moxifloxacian', '2017-12-27 13:42:41'),
(37, 'Ceftibuten', '2017-12-27 13:44:30'),
(38, 'Nitazoxanide', '2017-12-27 13:59:04'),
(39, 'Dexlansoprazole', '2017-12-27 14:01:05'),
(40, 'Calcium+Vit.C+Vit.D', '2017-12-27 14:39:13'),
(41, 'Dexibuprofen', '2017-12-27 14:44:05'),
(42, 'Etoricoxib', '2017-12-27 14:45:17'),
(43, 'Tapentadol', '2017-12-27 14:47:26'),
(44, 'Paracetamol+Tramadol', '2017-12-27 14:48:52'),
(45, 'Mouth Wash', '2017-12-27 14:50:31'),
(46, 'Tolperisone', '2017-12-27 14:51:48'),
(47, 'Vit. B-12', '2017-12-27 14:52:52'),
(48, 'Vit. B-1+B6+B12', '2017-12-27 14:53:42'),
(49, 'Ranitidine', '2017-12-31 06:57:09'),
(50, 'Aceclofenac', '2017-12-31 10:26:53'),
(51, 'Triamsilone Acitonide', '2017-12-31 13:54:26');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `com_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact_number` int(11) NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`com_id`, `name`, `contact_number`, `date_time`) VALUES
(1, 'Renata Limited', 1714070770, '0000-00-00 00:00:00'),
(2, 'Beximco', 1714070770, '0000-00-00 00:00:00'),
(3, 'Drug International LTD', 2147483647, '2017-12-13 16:16:02'),
(4, 'Incepta Pharmaceuticals Ltd.', 54654, '2017-12-13 16:16:35');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `createDTM` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `name`, `phone`, `password`, `age`, `createDTM`) VALUES
(1, 'Md jamal', 1923101010, '986d5aaaeb08171bc9198999096ee094a9c349b1', 24, '2021-03-31 10:44:23'),
(2, 'Md tobi', 1912121212, '7c222fb2927d828af22f592134e8932480637c0d', 28, '2021-03-31 10:45:49'),
(3, 'sumon', 1631707070, '7c222fb2927d828af22f592134e8932480637c0d', 30, '2021-04-17 06:07:55'),
(4, 'asasdfsa', 1957575757, '7c222fb2927d828af22f592134e8932480637c0d', 30, '2021-04-18 10:37:10'),
(5, 'asasdfsa', 1921565656, '7c222fb2927d828af22f592134e8932480637c0d', 25, '2021-04-18 10:37:49');

-- --------------------------------------------------------

--
-- Table structure for table `digest`
--

CREATE TABLE `digest` (
  `digest_id` int(11) NOT NULL,
  `name` varchar(252) NOT NULL,
  `createDTM` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `digest`
--

INSERT INTO `digest` (`digest_id`, `name`, `createDTM`) VALUES
(1, 'test', '2021-04-17 15:57:22'),
(2, 'test 2', '2021-04-17 15:57:28'),
(3, 'val', '2021-04-17 15:58:11'),
(4, 'you', '2021-04-18 16:51:08');

-- --------------------------------------------------------

--
-- Table structure for table `getadvice`
--

CREATE TABLE `getadvice` (
  `advice_id` int(11) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `problem` varchar(255) NOT NULL,
  `t_l` varchar(255) DEFAULT NULL,
  `t_r` varchar(255) DEFAULT NULL,
  `b_l` varchar(255) DEFAULT NULL,
  `b_r` varchar(255) DEFAULT NULL,
  `createDTM` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `getadvice`
--

INSERT INTO `getadvice` (`advice_id`, `prescription_id`, `problem`, `t_l`, `t_r`, `b_l`, `b_r`, `createDTM`) VALUES
(1, 1, 'rururtu', '', '8', '', '', '2021-04-17 04:22:59'),
(2, 2, 'fdgdfg', '', '6', '', '', '2021-04-17 04:27:40'),
(3, 4, 'RCT', '', '9', '', '', '2021-04-17 06:19:52'),
(4, 5, 'RCT', '', '9', '', '', '2021-04-17 06:24:49'),
(5, 8, 'RCT', '', '5', '', '', '2021-04-18 10:49:30');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `med_id` int(11) NOT NULL,
  `name` varchar(155) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `com_id` int(11) NOT NULL,
  `type` enum('Capsule','Tablet','Syrup','Injection') NOT NULL DEFAULT 'Tablet',
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`med_id`, `name`, `cat_id`, `com_id`, `type`, `date_time`) VALUES
(1, 'Triocim 200 mg', 1, 2, 'Capsule', '0000-00-00 00:00:00'),
(2, 'Maxpro-20mg', 10, 1, 'Tablet', '2017-12-26 06:41:49'),
(3, 'Maxpro-20mg', 10, 1, 'Capsule', '2017-12-26 06:41:35'),
(4, 'Maxpro-40mg', 10, 1, 'Injection', '2017-12-26 06:41:15'),
(5, 'Maxpro-40mg', 10, 1, 'Tablet', '2017-12-26 06:42:41'),
(6, 'Maxpro-40mg', 10, 1, 'Capsule', '2017-12-26 06:42:59'),
(7, 'Profast-20mg', 7, 1, 'Tablet', '2017-12-31 06:48:13'),
(8, 'Prazole-20mg', 9, 1, 'Capsule', '2017-12-31 06:55:19'),
(9, 'Protonil-20mg', 8, 1, 'Tablet', '2017-12-26 06:45:27'),
(10, 'Protonil-40mg', 8, 1, 'Tablet', '2017-12-26 06:45:50'),
(11, 'Norma-H-150mg', 49, 1, 'Tablet', '2017-12-31 06:57:22'),
(12, 'Calcin-500mg', 19, 1, 'Tablet', '2017-12-26 06:48:21'),
(13, 'Calcin-D-500mg', 18, 1, 'Tablet', '2017-12-26 06:51:22'),
(14, 'Calcin-D-200IU', 18, 1, 'Tablet', '2017-12-26 06:51:01'),
(15, 'Calcin-M', 20, 1, 'Tablet', '2017-12-26 06:51:58'),
(16, 'Calcin-O-400mg', 16, 1, 'Tablet', '2017-12-26 06:53:49'),
(17, 'Calcin-O DS 740mg', 16, 1, 'Tablet', '2017-12-26 06:54:38'),
(18, 'Rolac-10mg', 15, 1, 'Tablet', '2017-12-26 06:55:42'),
(19, 'Rolac-10mg', 15, 1, 'Injection', '2017-12-26 06:56:54'),
(20, 'Rolac-30mg', 15, 1, 'Injection', '2017-12-26 06:57:19'),
(21, 'Rolac-60mg', 15, 1, 'Injection', '2017-12-26 06:57:39'),
(22, 'Flustar 250mg', 26, 1, 'Capsule', '2017-12-26 06:59:41'),
(23, 'Flustar 500mg', 26, 1, 'Capsule', '2017-12-26 07:00:23'),
(24, 'Furocef-125mg', 27, 1, 'Tablet', '2017-12-26 16:30:42'),
(25, 'Furocef-250mg', 27, 1, 'Tablet', '2017-12-26 16:31:27'),
(26, 'Furocef-500mg', 27, 1, 'Tablet', '2017-12-27 12:48:44'),
(27, 'Furocef-250mg', 27, 1, 'Injection', '2017-12-31 06:44:08'),
(28, 'Furocef-750mg', 27, 1, 'Injection', '2017-12-27 12:50:03'),
(29, 'Furoclav-250mg', 28, 1, 'Tablet', '2017-12-27 12:56:06'),
(30, 'Furoclav-500mg', 28, 1, 'Tablet', '2017-12-27 12:56:28'),
(31, 'Cebuten-250mg', 29, 1, 'Capsule', '2017-12-31 12:19:30'),
(32, 'Cebuten-500mg', 29, 1, 'Capsule', '2017-12-31 12:19:40'),
(33, 'Orcef-200mg', 1, 1, 'Tablet', '2017-12-27 12:58:18'),
(34, 'Orcef-400mg', 1, 1, 'Tablet', '2017-12-27 12:58:49'),
(35, 'Orcef-200mg', 1, 1, 'Capsule', '2017-12-27 12:59:34'),
(36, 'Orcef DS-30ml :DPS', 31, 1, '', '2017-12-27 13:00:38'),
(37, 'Ceftizone-250mg', 32, 1, 'Injection', '2017-12-27 13:01:44'),
(38, 'Ceftizone-500mg', 32, 1, 'Injection', '2017-12-27 13:02:46'),
(39, 'Xamic-500mg', 33, 1, 'Capsule', '2017-12-27 13:03:47'),
(40, 'Xamic-500mg', 33, 1, 'Injection', '2017-12-27 13:04:08'),
(41, 'Adora-500mg', 34, 4, 'Capsule', '2017-12-27 13:13:55'),
(42, 'Adora-60ml', 34, 4, 'Syrup', '2017-12-27 13:33:10'),
(43, 'Clindacin-300mg', 35, 4, 'Capsule', '2017-12-27 13:35:28'),
(44, 'Kilbac 250mg', 2, 4, 'Tablet', '2017-12-27 13:36:45'),
(45, 'Kilbac-500mg', 2, 4, 'Tablet', '2017-12-27 13:37:28'),
(46, 'Cefaclav-125mg', 28, 4, 'Tablet', '2017-12-27 13:38:56'),
(47, 'Cefaclav-250mg', 28, 4, 'Tablet', '2017-12-27 13:39:19'),
(48, 'Cefaclav-500mg', 28, 4, 'Tablet', '2017-12-27 13:39:58'),
(49, 'Emixef-200mg', 30, 4, 'Capsule', '2017-12-27 13:41:01'),
(50, 'Emixef-400mg', 30, 4, 'Capsule', '2017-12-27 13:41:37'),
(51, 'Moxquin-400mg', 36, 4, 'Tablet', '2017-12-27 13:43:07'),
(52, 'Cefamax-400mg', 37, 4, 'Capsule', '2017-12-27 13:44:50'),
(53, 'Flamyd-250mg', 3, 4, 'Tablet', '2017-12-27 13:47:38'),
(54, 'Nitazox-500mg', 38, 4, 'Tablet', '2017-12-27 14:00:23'),
(55, 'Delanix-30mg', 39, 4, 'Capsule', '2017-12-27 14:03:04'),
(56, 'Delanix-60mg', 39, 4, 'Capsule', '2017-12-27 14:02:59'),
(57, 'Pantonix-20mg', 8, 4, 'Tablet', '2017-12-27 14:07:16'),
(58, 'Pantonix-40mg', 8, 4, 'Tablet', '2017-12-31 12:28:52'),
(59, 'Esonix-20mg', 10, 4, 'Capsule', '2017-12-27 14:37:18'),
(60, 'Esonix-40mg', 10, 4, 'Capsule', '2017-12-27 14:37:40'),
(61, 'Cavic-C', 40, 4, 'Tablet', '2017-12-27 14:39:39'),
(62, 'Cavic-C-Plus', 40, 4, 'Tablet', '2017-12-27 14:40:10'),
(63, 'Etorac-10mg', 24, 4, 'Tablet', '2017-12-27 14:41:29'),
(64, 'Etorac-30mg', 24, 4, 'Injection', '2017-12-27 14:42:10'),
(65, 'Etorac-60mg', 24, 4, 'Injection', '2017-12-27 14:42:57'),
(66, 'Purifen-300mg', 41, 4, 'Tablet', '2017-12-27 14:44:31'),
(67, 'Oricox-90mg', 42, 4, 'Tablet', '2017-12-27 14:45:47'),
(68, 'Oricox-120mg', 42, 4, 'Tablet', '2017-12-27 14:46:22'),
(69, 'Centradol-50mg', 43, 4, 'Tablet', '2017-12-27 14:47:56'),
(70, 'Resadol', 44, 4, 'Tablet', '2017-12-27 14:49:33'),
(71, 'Oroclen', 45, 4, '', '2017-12-27 14:50:53'),
(72, 'Myolax-50mg', 46, 4, 'Tablet', '2017-12-27 14:52:25'),
(73, 'Mecolagin', 47, 4, 'Tablet', '2017-12-27 14:53:18'),
(74, 'Vitabion', 48, 4, 'Tablet', '2017-12-27 14:54:25'),
(75, 'Intrax-500mg', 33, 4, 'Capsule', '2017-12-27 14:55:05'),
(76, 'T-CEF-200mg', 1, 3, 'Capsule', '2017-12-27 15:00:49'),
(77, 'T-CEF-400mg', 1, 3, 'Capsule', '2017-12-27 15:02:23'),
(78, 'T-CEF-50ml', 1, 3, 'Syrup', '2017-12-27 15:04:17'),
(79, 'T-CEF-30ml', 1, 3, 'Syrup', '2017-12-27 15:04:09'),
(80, 'T-CEF-50ml DS', 1, 3, 'Syrup', '2017-12-27 15:05:07'),
(81, 'Ceclofen-100mg', 50, 1, 'Tablet', '2017-12-31 12:10:30'),
(82, 'Flamyd-500mg', 3, 4, 'Tablet', '2017-12-31 12:27:07'),
(83, 'Flupen-250mg', 26, 3, 'Capsule', '2017-12-31 12:54:00'),
(84, 'Flupen-500mg', 26, 3, 'Capsule', '2017-12-31 12:54:50'),
(85, 'Furex-250mg', 27, 3, 'Tablet', '2017-12-31 12:57:18'),
(86, 'Furex-500mg', 27, 3, 'Tablet', '2017-12-31 12:58:01'),
(87, 'Furex-70ml', 27, 3, 'Tablet', '2017-12-31 12:58:29'),
(88, 'Fuclav-250mg', 28, 3, 'Tablet', '2017-12-31 13:00:04'),
(89, 'Fuclav-500mg', 28, 3, 'Tablet', '2017-12-31 13:00:26'),
(90, 'Fuclav-70ml', 28, 3, 'Tablet', '2017-12-31 13:00:48'),
(91, 'Nofenac-100mg', 50, 3, 'Tablet', '2017-12-31 13:09:02'),
(92, 'Pair-10mg', 15, 3, 'Tablet', '2017-12-31 13:10:24'),
(93, 'Pair-30mg', 15, 3, 'Injection', '2017-12-31 13:11:46'),
(94, 'Caldil-Plus-400mg', 18, 3, 'Tablet', '2017-12-31 13:13:25'),
(95, 'Caldin-OT-400mg', 16, 3, 'Tablet', '2017-12-31 13:14:05'),
(96, 'Seacal-D-400mg', 18, 3, 'Tablet', '2017-12-31 13:38:09'),
(97, 'Block-T-500mg', 33, 3, 'Tablet', '2017-12-31 13:41:24'),
(98, 'Block-T-500mg', 33, 3, 'Injection', '2017-12-31 13:42:25'),
(99, 'Trialon Oral Paste', 51, 3, 'Tablet', '2017-12-31 13:56:04'),
(100, 'Cosec-20mg', 9, 3, 'Capsule', '2017-12-31 13:57:25'),
(101, 'Cosec-40mg', 9, 3, 'Capsule', '2017-12-31 13:58:08'),
(102, 'Pansec-20mg', 13, 3, 'Tablet', '2017-12-31 13:58:39'),
(103, 'Pansec-40mg', 13, 3, 'Tablet', '2017-12-31 13:59:22'),
(104, 'Pronex-20mg', 10, 3, 'Tablet', '2017-12-31 14:00:04'),
(105, 'Pronex-40mg', 10, 3, 'Tablet', '2017-12-31 14:15:21'),
(106, 'Pronex-20mg', 10, 3, 'Capsule', '2017-12-31 14:15:42'),
(107, 'Pronex-40mg', 10, 3, 'Capsule', '2017-12-31 14:16:00'),
(108, 'Rabesec-20mg', 7, 3, 'Tablet', '2017-12-31 14:21:02');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `prescription_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `createDTM` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`prescription_id`, `customer_id`, `createDTM`) VALUES
(1, 1, '2021-04-17 10:22:58'),
(2, 2, '2021-04-17 10:27:40'),
(3, 3, '2021-04-17 12:08:38'),
(4, 3, '2021-04-17 12:19:52'),
(5, 1, '2021-04-17 12:24:49'),
(6, 2, '2021-04-17 12:32:48'),
(7, 1, '2021-04-18 14:22:19'),
(8, 5, '2021-04-18 16:49:29');

-- --------------------------------------------------------

--
-- Table structure for table `prescription_item`
--

CREATE TABLE `prescription_item` (
  `prescription_item_id` int(11) NOT NULL,
  `prescription_id` int(11) DEFAULT NULL,
  `digest_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `dosage` varchar(255) NOT NULL,
  `days` varchar(255) NOT NULL,
  `before_after` varchar(255) NOT NULL,
  `when` int(11) NOT NULL,
  `createDTM` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prescription_item`
--

INSERT INTO `prescription_item` (`prescription_item_id`, `prescription_id`, `digest_id`, `name`, `type`, `dosage`, `days`, `before_after`, `when`, `createDTM`) VALUES
(1, 1, NULL, 'Triocim 200 mg', 'Capsule', '1+0+1', '7', 'Before', 0, '2021-04-17 04:22:58'),
(2, 1, NULL, 'Pronex-20mg', 'Capsule', '1+1+0', '10', 'Before', 0, '2021-04-17 04:22:58'),
(3, 2, NULL, 'Triocim 200 mg', 'Capsule', '1+1+0', '6', 'After', 1, '2021-04-17 04:27:40'),
(4, 2, NULL, 'Triocim 200 mg', 'Capsule', '0+1+1', '11', 'Before', 0, '2021-04-17 04:27:40'),
(5, 3, NULL, 'Prazole-20mg', 'Capsule', '1+0+0', '9', 'After', 1, '2021-04-17 06:08:38'),
(6, 3, NULL, 'Triocim 200 mg', 'Capsule', '0+0+1', '2', 'After', 0, '2021-04-17 06:08:38'),
(7, 4, NULL, 'T-CEF-50ml', 'Syrup', '1+0+0', '4', 'After', 0, '2021-04-17 06:19:52'),
(8, 4, NULL, 'Protonil-20mg', 'Tablet', '1+0+0', '5', 'Before', 0, '2021-04-17 06:19:52'),
(9, 5, NULL, 'Adora-60ml', 'Syrup', '1+0+1', '5', 'After', 0, '2021-04-17 06:24:49'),
(10, 5, NULL, 'Pansec-40mg', 'Tablet', '0+1+0', '4', 'Before', 0, '2021-04-17 06:24:49'),
(11, 6, NULL, 'Adora-60ml', 'Syrup', '1+0+0', '5', 'Before', 0, '2021-04-17 06:32:48'),
(13, NULL, 1, 'Cosec-20mg', 'Capsule', '0+1+0', '11', 'Before', 0, '2021-04-17 09:54:30'),
(14, NULL, 2, 'T-CEF-50ml DS', 'Syrup', '1+0+0', '10', 'Before', 0, '2021-04-17 09:54:53'),
(15, NULL, 2, 'Cosec-20mg', 'Capsule', '0+1+0', '11', 'Before', 0, '2021-04-17 09:54:53'),
(16, NULL, 3, 'T-CEF-50ml DS', 'Syrup', '1+0+0', '10', 'Before', 0, '2021-04-17 09:58:11'),
(17, NULL, 3, 'Cosec-20mg', 'Capsule', '0+1+0', '11', 'Before', 0, '2021-04-17 09:58:11'),
(27, 8, NULL, 'T-CEF-30ml', 'Syrup', '1+0+1', '10', 'Before', 0, '2021-04-18 10:49:29'),
(28, NULL, 4, 'Triocim 200 mg', 'Capsule', '1+0+0', '5', 'After', 0, '2021-04-18 10:51:08'),
(29, NULL, 4, 'Cosec-40mg', 'Capsule', '1+0+0', '3', 'Before', 0, '2021-04-18 10:51:08'),
(30, NULL, 1, 'Cavic-C-Plus', 'Capsule', '0+1+0', '17', 'Before', 0, '2021-04-19 06:48:36');

-- --------------------------------------------------------

--
-- Table structure for table `problem`
--

CREATE TABLE `problem` (
  `problem_id` int(11) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `problem` varchar(255) NOT NULL,
  `t_l` varchar(255) DEFAULT NULL,
  `t_r` varchar(255) DEFAULT NULL,
  `b_l` varchar(255) DEFAULT NULL,
  `b_r` varchar(255) DEFAULT NULL,
  `createDTM` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `problem`
--

INSERT INTO `problem` (`problem_id`, `prescription_id`, `problem`, `t_l`, `t_r`, `b_l`, `b_r`, `createDTM`) VALUES
(1, 1, 'rururtu', '', '8', '', '', '2021-04-17 04:22:58'),
(2, 2, 'fdgdfg', '', '6', '', '', '2021-04-17 04:27:40'),
(3, 4, 'hjkhlhkl', '', '9', '', '', '2021-04-17 06:19:52'),
(4, 5, 'xvdfdgfg', '', '6', '', '', '2021-04-17 06:24:49'),
(5, 8, 'gsdsdgsd', '', '8', '', '', '2021-04-18 10:49:30');

-- --------------------------------------------------------

--
-- Table structure for table `serial`
--

CREATE TABLE `serial` (
  `serial_no` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `createDTM` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `serial`
--

INSERT INTO `serial` (`serial_no`, `customer_id`, `date`, `createDTM`) VALUES
(1, 1, '2021-04-27', '2021-04-19 12:00:03'),
(2, 1, '2021-04-29', '2021-04-19 12:00:34'),
(3, 1, '2021-04-30', '2021-04-19 12:20:37'),
(4, 2, '2021-04-19', '2021-04-19 12:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `lebel` varchar(50) NOT NULL,
  `value` varchar(155) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `lebel`, `value`) VALUES
(1, 'ComName', 'Dentist Point'),
(2, 'Logo', 'logo.png'),
(3, 'address', 'Jessore, Khulna'),
(4, 'country', 'Bangladesh'),
(5, 'contact_number', '01924329315'),
(6, 'Owner', 'All-Mamun');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(155) NOT NULL,
  `pass` varchar(55) NOT NULL,
  `name` varchar(40) NOT NULL,
  `mobile` int(11) DEFAULT NULL,
  `address` text,
  `pic` varchar(100) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedBy` int(11) DEFAULT NULL,
  `updatedDtm` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` int(11) DEFAULT NULL,
  `deletedRole` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `email`, `password`, `pass`, `name`, `mobile`, `address`, `pic`, `role_id`, `status`, `createdBy`, `createdDtm`, `updatedBy`, `updatedDtm`, `deleted`, `deletedRole`) VALUES
(1, 'admin@gmail.com', '7c222fb2927d828af22f592134e8932480637c0d', '', 'Demo Name', NULL, NULL, '', 1, '1', 1, '2020-07-07 12:28:34', NULL, '2021-03-08 19:44:00', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advice`
--
ALTER TABLE `advice`
  ADD PRIMARY KEY (`ad_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `digest`
--
ALTER TABLE `digest`
  ADD PRIMARY KEY (`digest_id`);

--
-- Indexes for table `getadvice`
--
ALTER TABLE `getadvice`
  ADD PRIMARY KEY (`advice_id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`med_id`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`prescription_id`);

--
-- Indexes for table `prescription_item`
--
ALTER TABLE `prescription_item`
  ADD PRIMARY KEY (`prescription_item_id`);

--
-- Indexes for table `problem`
--
ALTER TABLE `problem`
  ADD PRIMARY KEY (`problem_id`);

--
-- Indexes for table `serial`
--
ALTER TABLE `serial`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `role_id` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advice`
--
ALTER TABLE `advice`
  MODIFY `ad_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `com_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `digest`
--
ALTER TABLE `digest`
  MODIFY `digest_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `getadvice`
--
ALTER TABLE `getadvice`
  MODIFY `advice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `med_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `prescription_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `prescription_item`
--
ALTER TABLE `prescription_item`
  MODIFY `prescription_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `problem`
--
ALTER TABLE `problem`
  MODIFY `problem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `serial`
--
ALTER TABLE `serial`
  MODIFY `serial_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
